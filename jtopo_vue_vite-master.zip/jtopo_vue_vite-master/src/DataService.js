/**
 * 负责业务数据的加载、格式化、转换等，将数据预处理，让后续的绘制更简单
 * 
 * 不关心如何绘制
 */
class DataService{
    constructor(){
    }

    /**
     * 加载数据
     * @returns 
     */
    loadData(){
        //TODO: 
        let data = {};
        return data;
    }
}

export const dataService = new DataService();