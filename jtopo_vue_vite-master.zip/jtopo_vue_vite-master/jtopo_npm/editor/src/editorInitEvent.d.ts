export declare function initEditorStage(editor: any): void;
