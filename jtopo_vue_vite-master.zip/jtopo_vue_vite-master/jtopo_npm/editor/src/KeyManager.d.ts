import Editor from './Editor';
export declare const DropToKey = "Shift";
export declare function initEditorKeyboard(editor: Editor): void;
