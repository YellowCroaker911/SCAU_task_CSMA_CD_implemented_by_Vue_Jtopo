export declare function alignHandler(align: any, editor: any): void;
