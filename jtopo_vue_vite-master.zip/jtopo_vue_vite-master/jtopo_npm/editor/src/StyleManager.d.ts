import { DisplayObject } from '@jtopo/core';
export declare function copySetStyle(target: DisplayObject, source: DisplayObject): void;
