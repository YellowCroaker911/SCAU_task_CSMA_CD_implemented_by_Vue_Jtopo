import Editor from './Editor';
export declare function showRuler(editor: Editor, origin: any): void;
export declare function hideRuler(editor: Editor, origin: any): void;
export declare function updateRuler(editor: Editor): void;
export declare function initRuler(editor: any): void;
