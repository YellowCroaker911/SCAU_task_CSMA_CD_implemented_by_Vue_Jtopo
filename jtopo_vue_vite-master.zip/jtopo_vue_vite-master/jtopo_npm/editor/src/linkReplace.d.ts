export declare function linkReplace(link: any, source: any): void;
