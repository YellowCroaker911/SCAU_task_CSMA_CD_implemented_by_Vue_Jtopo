export declare class InputTextfield {
    editor: any;
    stage: any;
    textarea: any;
    constructor(editor: any);
    attachTo(currObj: any, e: any): void;
    setValue(value: any): void;
    setSize(w: any, h: any): void;
    show(x: any, y: any): void;
    hide(): void;
    onkeydown(e: any): void;
}
export { InputTextfield as default };
