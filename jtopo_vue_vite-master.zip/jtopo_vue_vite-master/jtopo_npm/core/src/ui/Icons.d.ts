export declare function bgGrid(w: any, h: any, row: any, col: any, fillStyle?: string, strokeStyle?: string): string;
export declare function svgToImageUrl(svgString: any): string;
export declare let Icons: any;
