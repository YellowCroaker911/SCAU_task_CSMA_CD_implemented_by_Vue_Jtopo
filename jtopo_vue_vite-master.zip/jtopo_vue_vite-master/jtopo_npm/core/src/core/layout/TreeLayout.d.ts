import VirtualTree from './VirtualTree';
export declare function getTreeLayoutPositions(tree: VirtualTree, opt?: {}): any[];
