export declare class Intersect {
    x: number;
    y: number;
    object: any;
    seg: any;
    dist: any;
    segIndex: any;
    segLen: any;
    projectionLen: any;
    rate: any;
    length: number;
    constructor(p: any);
}
export { Intersect as default };
