/**
 * 主题
 */
export declare const Theme: any;
