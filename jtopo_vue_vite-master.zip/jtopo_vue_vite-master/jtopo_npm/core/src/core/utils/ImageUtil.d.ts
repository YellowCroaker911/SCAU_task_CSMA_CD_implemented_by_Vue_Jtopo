export declare function Base64ToImage(base64img: string, callback: any): HTMLImageElement;
