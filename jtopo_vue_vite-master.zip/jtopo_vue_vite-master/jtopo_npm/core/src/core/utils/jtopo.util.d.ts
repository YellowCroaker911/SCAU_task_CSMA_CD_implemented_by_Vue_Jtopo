export declare let util: any;
declare function constraint(object: any, options: any): any;
export { util as default, constraint };
